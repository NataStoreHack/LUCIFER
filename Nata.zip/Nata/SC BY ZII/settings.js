global.prefa = ['','!','.',',','🐤','🗿']

global.owner = ['6285150902407']
global.botname = 'Zii X Gixx BOT'
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "Zii Official"
global.sticker2 = "🌜"